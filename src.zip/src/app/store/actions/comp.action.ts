export class Fetchcity{
    static readonly type='[Fetchcity] Get';
}